import logo from './logo.svg';
import './App.css';
import Form from './Component/Form';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';


function App() {
  return (
    <>
    <Form/>
    <ToastContainer/>
    </>
  );
}

export default App;
